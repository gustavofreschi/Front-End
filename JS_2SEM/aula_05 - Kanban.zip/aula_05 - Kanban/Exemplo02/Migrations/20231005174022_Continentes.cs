﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Exemplo02.Migrations
{
    /// <inheritdoc />
    public partial class Continentes : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
